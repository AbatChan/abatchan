(function nikaWidget(global) {
  'use strict';

  const WIDGET_SOURCE = (document.currentScript && document.currentScript.src) || '';

  const DEFAULTS = Object.freeze({
    name: 'Nika',
    subtitle: 'website guide',
    avatar: '',
    disclaimer: "Answers use this website's configured content. Review important information.",
    suggestions: [
      { label: 'Find the right service', description: 'See what fits your needs' },
      { label: 'How does it work?', description: 'Review the process' },
      { label: 'Compare the options', description: 'See plans or packages' }
    ],
    placeholder: 'Ask about this website...',
    endpoint: '/wp-json/nika/v1',
    autoNavigate: true,
    dictation: true,
    actionMode: 'ask',
    answerDepth: 'concise',
    accent: '#6366f1',
    position: 'right',
    contextCharacters: 12000,
    historyTurns: 10
  });

  const clean = value => String(value == null ? '' : value).trim();
  const escapeHtml = value => clean(value).replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
  const normalizePath = value => {
    try {
      const url = new URL(value, location.href);
      return `${url.pathname.replace(/\/+$/, '') || '/'}${url.hash}`;
    } catch {
      return '';
    }
  };
  const textKey = value => clean(value).toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
  const normalizeSuggestions = value => (Array.isArray(value) ? value : []).slice(0, 3).map(item => typeof item === 'string'
    ? { label: clean(item), description: '' }
    : { label: clean(item?.label), description: clean(item?.description), question: clean(item?.question) }
  ).filter(item => item.label);

  const visiblePixels = node => {
    if (!node || node.hidden || node.getAttribute('aria-hidden') === 'true') return 0;
    const style = getComputedStyle(node);
    if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity) === 0) return 0;
    const rect = node.getBoundingClientRect();
    const width = Math.max(0, Math.min(rect.right, innerWidth) - Math.max(rect.left, 0));
    const height = Math.max(0, Math.min(rect.bottom, innerHeight) - Math.max(rect.top, 0));
    return width * height;
  };

  const viewLabel = node => clean(
    node && (node.dataset.nikaLabel || node.getAttribute('aria-label') ||
      (node.getAttribute('aria-labelledby') && document.getElementById(node.getAttribute('aria-labelledby'))?.textContent) ||
      (node.matches('h1,h2,h3') ? node.textContent : node.querySelector('h1,h2,h3,[role="heading"]')?.textContent) ||
      (node.matches('summary') ? node.textContent : node.querySelector('summary')?.textContent) || node.textContent)
  ).replace(/\s+/g, ' ').slice(0, 180);

  function activeView(main) {
    const candidates = [
      ...document.querySelectorAll('dialog[open],[role="dialog"]:not([hidden]),[aria-modal="true"]:not([hidden])'),
      ...main.querySelectorAll('[role="tabpanel"]:not([hidden]),details[open],section,article,h1,h2,h3,[data-nika-label]')
    ];
    const focusNode = document.elementFromPoint(
      Math.max(1, Math.min(innerWidth - 1, innerWidth * .34)),
      Math.max(1, Math.min(innerHeight - 1, innerHeight * .5))
    )?.closest('section,article,h1,h2,h3,[data-nika-label]');
    return candidates.map(node => {
      const pixels = visiblePixels(node);
      const rect = node.getBoundingClientRect();
      const focusBand = Math.max(0, Math.min(rect.bottom, innerHeight * .66) - Math.max(rect.top, innerHeight * .34));
      const priority = node.matches('dialog,[role="dialog"],[aria-modal="true"]') ? 4
        : node.matches('[role="tabpanel"]') ? 3
          : node.matches('details[open]') ? 2 : 1;
      return { node, pixels, priority, focusBand, focusHit: node === focusNode || node.contains(focusNode), distance: Math.abs((rect.top + rect.bottom) / 2 - innerHeight * .5) };
    }).filter(item => item.pixels > 0 && viewLabel(item.node))
      .sort((a, b) => b.priority - a.priority || Number(b.focusHit) - Number(a.focusHit) || b.focusBand - a.focusBand || a.distance - b.distance)[0]?.node || null;
  }

  function pageContext(limit) {
    const main = document.querySelector('main,[role="main"],article') || document.body;
    const clone = main.cloneNode(true);
    clone.querySelectorAll('script,style,noscript,svg,form,nav,footer,[aria-hidden="true"]').forEach(node => node.remove());
    const headings = [...main.querySelectorAll('h1,h2,h3')].slice(0, 40).map(node => ({
      id: clean(node.id),
      text: clean(node.textContent).slice(0, 180)
    })).filter(item => item.text);
    const active = activeView(main);
    const activeText = active ? clean(active.textContent).replace(/\s+/g, ' ').slice(0, 2000) : '';
    const path = `${location.pathname.replace(/\/+$/, '') || '/'}${/^#[a-z0-9_-]{1,100}$/i.test(location.hash) ? location.hash : ''}`;
    const limitations = [];
    if ([...main.querySelectorAll('iframe')].some(node => visiblePixels(node))) limitations.push('Visible embedded-frame content is not included in the text snapshot.');
    if ([...main.querySelectorAll('canvas')].some(node => visiblePixels(node))) limitations.push('Visible canvas pixels cannot be inspected as page text.');
    if ([...main.querySelectorAll('img')].some(node => visiblePixels(node))) limitations.push('Image pixels are not inspected; only surrounding text and accessible labels are available.');
    return {
      // Search parameters can contain account IDs, emails and temporary
      // tokens. Page awareness never needs them, so they are not transmitted.
      url: `${location.origin}${path}`,
      path,
      title: clean(document.title).slice(0, 180),
      heading: clean(main.querySelector('h1')?.textContent).replace(/\s+/g, ' ').slice(0, 180),
      activeSection: active ? {
        id: clean(active.id).slice(0, 100),
        label: viewLabel(active),
        kind: active.matches('dialog,[role="dialog"],[aria-modal="true"]') ? 'dialog'
          : active.matches('[role="tabpanel"]') ? 'tab'
            : active.matches('details[open]') ? 'details' : 'section',
        text: activeText
      } : null,
      limitations,
      headings,
      // innerText follows the rendered state, so CSS-hidden menus and inactive
      // responsive variants do not masquerade as visible content. The clone is
      // only a fallback for non-painting test/browser environments.
      text: clean(main.innerText || clone.textContent).replace(/\s+/g, ' ').slice(0, limit)
    };
  }

  function allowedDestination(href, pages) {
    let target;
    try { target = new URL(href, location.href); } catch { return null; }
    if (target.origin !== location.origin) return null;
    const allowed = pages.map(page => normalizePath(typeof page === 'string' ? page : page.url || page.path));
    const targetPath = normalizePath(target.href);
    const targetBase = targetPath.split('#')[0];
    if (!allowed.some(path => path.split('#')[0] === targetBase)) return null;
    return target;
  }

  function findTarget(url, label) {
    if (url.hash) {
      const byId = document.getElementById(decodeURIComponent(url.hash.slice(1)));
      if (byId) return byId;
    }
    const wanted = textKey(label);
    if (!wanted) return null;
    const matches = [...document.querySelectorAll('h1,h2,h3,[data-nika-label]')].filter(node => {
      const candidate = textKey(node.dataset.nikaLabel || node.textContent);
      return candidate === wanted || candidate.includes(wanted) || wanted.includes(candidate);
    });
    if (matches.length < 2) return matches[0] || null;
    const explicit = matches.filter(node => textKey(node.dataset.nikaLabel) === wanted);
    if (explicit.length === 1) return explicit[0];
    const visible = matches.filter(node => visiblePixels(node) > 0);
    // A wrong highlight is worse than no highlight. Duplicate off-screen or
    // repeated responsive headings need an id/hash or one unique
    // data-nika-label before Nika will choose between them.
    return visible.length === 1 ? visible[0] : null;
  }

  function highlightTarget(target, label, accent) {
    if (!target) return false;
    target.scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'center' });
    const old = { outline: target.style.outline, outlineOffset: target.style.outlineOffset, borderRadius: target.style.borderRadius };
    target.style.outline = `3px solid ${/^#[0-9a-f]{6}$/i.test(accent || '') ? accent : DEFAULTS.accent}`;
    target.style.outlineOffset = '8px';
    target.style.borderRadius = target.style.borderRadius || '6px';
    target.setAttribute('data-nika-highlight', clean(label) || 'Nika destination');
    setTimeout(() => {
      target.style.outline = old.outline;
      target.style.outlineOffset = old.outlineOffset;
      target.style.borderRadius = old.borderRadius;
      target.removeAttribute('data-nika-highlight');
    }, 9000);
    return true;
  }

  function navigate(action, pages, accent) {
    const target = allowedDestination(action && action.href, pages);
    if (!target) return { ok: false, reason: 'destination_not_allowed' };
    const current = `${location.pathname.replace(/\/+$/, '') || '/'}`;
    const next = `${target.pathname.replace(/\/+$/, '') || '/'}`;
    if (current === next) {
      const found = findTarget(target, action.label);
      return { ok: highlightTarget(found, action.label, accent), samePage: true, reason: found ? '' : 'target_not_unique' };
    }
    sessionStorage.setItem('nika.pending', JSON.stringify({ href: `${target.pathname}${target.hash}`, label: clean(action.label).slice(0, 180), accent }));
    location.assign(`${target.pathname}${target.search}${target.hash}`);
    return { ok: true, samePage: false };
  }

  function restorePending() {
    let pending = null;
    try { pending = JSON.parse(sessionStorage.getItem('nika.pending') || 'null'); } catch {}
    if (!pending) return;
    const url = allowedDestination(pending.href, [pending.href]);
    if (!url || url.pathname !== location.pathname) return;
    let attempts = 0;
    const restore = () => {
      attempts += 1;
      const target = findTarget(url, pending.label);
      if (highlightTarget(target, pending.label, pending.accent)) {
        sessionStorage.removeItem('nika.pending');
        return;
      }
      // Builders and animation libraries often insert or reveal headings after
      // DOMContentLoaded. Retry briefly instead of silently losing the action.
      if (attempts < 12) setTimeout(restore, 180);
      else sessionStorage.removeItem('nika.pending');
    };
    setTimeout(restore, 180);
  }

  function template(name, suggestions, placeholder, avatar, subtitle, disclaimer) {
    name = escapeHtml(name);
    placeholder = escapeHtml(placeholder);
    avatar = escapeHtml(avatar);
    subtitle = escapeHtml(subtitle || 'website guide');
    disclaimer = escapeHtml(disclaimer);
    const icons = ['work', 'process', 'options'];
    const starters = normalizeSuggestions(suggestions).map((item,index) => `<button type="button" data-question="${escapeHtml(item.question || item.label)}"><i class="nika-suggestion-icon nika-suggestion-icon--${icons[index] || 'options'}" aria-hidden="true"></i><span><strong>${escapeHtml(item.label)}</strong>${item.description ? `<small>${escapeHtml(item.description)}</small>` : ''}</span><b class="nika-chevron" aria-hidden="true">›</b></button>`).join('');
    return `<div class="nika-root">
      <button class="nika-launch" type="button" aria-label="Open ${name}" aria-expanded="false"><svg class="nika-launch-chat" viewBox="0 0 24 24" aria-hidden="true"><path d="M21 11.5a8.4 8.4 0 0 1-9 8.4 9.6 9.6 0 0 1-2.8-.4L4 21.5l1.4-4.2A8.3 8.3 0 0 1 3.5 11.5a8.4 8.4 0 0 1 9-8.4 8.4 8.4 0 0 1 8.5 8.4Z"/></svg><svg class="nika-launch-close" viewBox="0 0 24 24" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12"/></svg></button>
      <section class="nika-panel" aria-label="${name} website guide" hidden>
        <header>${avatar ? `<img src="${avatar}" alt="">` : ''}<div><strong>${name}</strong><span>${subtitle}</span></div><i class="nika-online" aria-label="Available"></i><button class="nika-close" type="button" aria-label="Clear conversation" title="Clear conversation"><svg viewBox="0 0 20 20" aria-hidden="true"><path d="M4.2 5.4h11.6M8 3.2h4M6.1 5.4l.7 11.1h6.4l.7-11.1M8.4 8.3v5.4M11.6 8.3v5.4"/></svg></button></header>
        <div class="nika-log" role="log" aria-live="polite"></div>
        <div class="nika-suggestions" aria-label="Suggested questions">${starters}</div>
        <div class="nika-status" aria-live="polite"></div>
        <form><textarea rows="1" maxlength="4000" placeholder="${placeholder}" aria-label="Message ${name}"></textarea><div class="nika-dictation" role="group" aria-label="Voice dictation" hidden><button class="nika-dictation-cancel" type="button" aria-label="Cancel dictation">×</button><canvas aria-hidden="true"></canvas><time aria-label="Dictation duration">0:00</time><button class="nika-dictation-stop" type="button" aria-label="Stop dictation">■</button></div><div class="nika-composer-rail"><div class="nika-composer-group"><div class="nika-menu-wrap"><button class="nika-choice nika-approval" type="button" aria-haspopup="menu" aria-expanded="false" title="Choose how site actions are approved"><svg viewBox="0 0 20 20" aria-hidden="true"><path d="M10 2.6 16 5v4.2c0 3.8-2.4 6.5-6 8.2-3.6-1.7-6-4.4-6-8.2V5l6-2.4Z"/><path d="m7.4 9.8 1.7 1.7 3.7-4"/></svg><span>Ask first</span><b aria-hidden="true">⌄</b></button><div class="nika-menu nika-approval-menu" role="menu" hidden><button type="button" role="menuitemradio" data-action-mode="ask"><strong>Ask before actions</strong><span>Confirm navigation each time</span></button><button type="button" role="menuitemradio" data-action-mode="allow"><strong>Allow site actions</strong><span>Navigate when I clearly ask</span></button></div></div></div><div class="nika-composer-group nika-composer-end"><div class="nika-menu-wrap"><button class="nika-choice nika-depth" type="button" aria-haspopup="menu" aria-expanded="false" title="Choose answer depth"><span>Concise</span><b aria-hidden="true">⌄</b></button><div class="nika-menu nika-depth-menu" role="menu" hidden><button type="button" role="menuitemradio" data-answer-depth="concise"><strong>Concise</strong><span>Fast, focused answers</span></button><button type="button" role="menuitemradio" data-answer-depth="detailed"><strong>Detailed</strong><span>More context when useful</span></button></div></div><button class="nika-mic" type="button" aria-label="Start dictation"><svg viewBox="0 0 20 20" aria-hidden="true"><path d="M10 2.5a3 3 0 0 0-3 3v4a3 3 0 0 0 6 0v-4a3 3 0 0 0-3-3Z"/><path d="M4.8 9.2a5.2 5.2 0 0 0 10.4 0M10 14.5v3M7.5 17.5h5"/></svg></button><button class="nika-send" type="submit" aria-label="Send"><svg viewBox="0 0 20 20" aria-hidden="true"><path d="m5 10 5-5 5 5M10 5v10"/></svg></button></div></div></form>
        <small>${disclaimer}</small>
      </section>
    </div>`;
  }

  async function mount(options) {
    if (document.querySelector('[data-nika-mounted]')) return;
    // Capture this before the first await. document.currentScript becomes null
    // after config loading, which otherwise makes a plain embed look for CSS
    // beside the host page instead of beside nika-widget.js.
    const scriptSource = WIDGET_SOURCE;
    const config = { ...DEFAULTS, ...(options || {}) };
    const endpoint = clean(config.endpoint).replace(/\/$/, '');
    let remote = {};
    try {
      const response = await fetch(`${endpoint}/config`, { headers: { Accept: 'application/json' }, credentials: 'same-origin' });
      if (response.ok) remote = await response.json();
    } catch {}
    const settings = { ...config, ...remote };
    if (settings.enabled === false) return;
    const pages = Array.isArray(settings.pages) ? settings.pages : [];
    const currentBase = normalizePath(location.href).split('#')[0];
    const blocked = Array.isArray(settings.blockedPaths) ? settings.blockedPaths.map(path => normalizePath(path).split('#')[0]) : [];
    // Exclusion is a privacy boundary, not merely a search-index preference.
    // Do not mount or capture visible text on account, checkout, admin or other
    // routes the owner excluded.
    if (blocked.includes(currentBase)) return;

    const host = document.createElement('div');
    host.dataset.nikaMounted = 'true';
    const root = host.attachShadow({ mode: 'open' });
    const css = document.createElement('link');
    css.rel = 'stylesheet';
    // Carry the script's own cache-busting query onto the stylesheet, otherwise an
    // upgraded site keeps serving the previous CSS from cache.
    css.href = settings.stylesheet || (() => {
      const from = scriptSource || location.href;
      const url = new URL('nika-widget.css', from);
      const search = new URL(from, location.href).search;
      if (search && !url.search) url.search = search;
      return url.href;
    })();
    const shell = document.createElement('div');
    const suggestions = normalizeSuggestions(settings.suggestions);
    shell.innerHTML = template(clean(settings.name) || DEFAULTS.name, suggestions.length ? suggestions : DEFAULTS.suggestions, clean(settings.placeholder) || DEFAULTS.placeholder, clean(settings.avatar), clean(settings.subtitle), clean(settings.disclaimer) || DEFAULTS.disclaimer);
    root.append(css, shell.firstElementChild);
    document.body.append(host);

    const q = selector => root.querySelector(selector);
    const panel = q('.nika-panel');
    const launch = q('.nika-launch');
    const close = q('.nika-close');
    const form = q('form');
    const input = q('textarea');
    const send = q('.nika-send');
    const mic = q('.nika-mic');
    const approval = q('.nika-approval');
    const depth = q('.nika-depth');
    const dictation = q('.nika-dictation');
    const dictationCanvas = q('.nika-dictation canvas');
    const dictationTime = q('.nika-dictation time');
    const dictationCancel = q('.nika-dictation-cancel');
    const dictationStop = q('.nika-dictation-stop');
    const log = q('.nika-log');
    const starters = q('.nika-suggestions');
    const status = q('.nika-status');
    const accent = /^#[0-9a-f]{6}$/i.test(clean(settings.accent)) ? clean(settings.accent) : DEFAULTS.accent;
    q('.nika-root').style.setProperty('--nika', accent);
    if (settings.position === 'left') q('.nika-root').classList.add('nika-left');
    const historyKey = `nika.history:${clean(settings.siteId) || location.host}`;
    const preferenceKey = clean(settings.siteId) || location.host;
    let actionMode = settings.actionMode === 'allow' ? 'allow' : 'ask';
    let answerDepth = settings.answerDepth === 'detailed' ? 'detailed' : 'concise';
    try {
      actionMode = localStorage.getItem(`nika.actionMode:${preferenceKey}`) === 'allow' ? 'allow' : actionMode;
      answerDepth = localStorage.getItem(`nika.answerDepth:${preferenceKey}`) === 'detailed' ? 'detailed' : answerDepth;
    } catch {}
    let history = [];
    try { history = JSON.parse(sessionStorage.getItem(historyKey) || '[]'); } catch {}
    if (!Array.isArray(history)) history = [];

    const setOpen = open => {
      panel.hidden = !open;
      launch.classList.toggle('is-open', open);
      launch.setAttribute('aria-expanded', String(open));
      launch.setAttribute('aria-label', `${open ? 'Close' : 'Open'} ${clean(settings.name) || DEFAULTS.name}`);
      if (open) setTimeout(() => input.focus(), 0);
    };
    launch.addEventListener('click', () => setOpen(panel.hidden));
    close.addEventListener('click', () => {
      log.textContent = '';
      history = [];
      try { sessionStorage.removeItem(historyKey); } catch {}
      if (starters) starters.hidden = false;
      status.textContent = '';
      syncEmptyState();
      input.focus();
    });

    // Before a conversation exists there is nothing to scroll, so the panel
    // should hug its content instead of reserving a tall empty log.
    const syncEmptyState = () => panel.classList.toggle('is-empty', !log.firstChild);
    syncEmptyState();

    const message = (role, text) => {
      if (starters) starters.hidden = true;
      const node = document.createElement('div');
      node.className = `nika-message ${role}`;
      node.textContent = clean(text);
      log.append(node);
      syncEmptyState();
      log.scrollTop = log.scrollHeight;
      return node;
    };
    history.forEach(turn => {
      if ((turn?.role === 'user' || turn?.role === 'assistant') && clean(turn.content)) message(turn.role, turn.content);
    });
    const closeMenus = () => {
      root.querySelectorAll('.nika-menu').forEach(menu => { menu.hidden = true; });
      root.querySelectorAll('.nika-choice').forEach(button => button.setAttribute('aria-expanded', 'false'));
    };
    const syncChoices = () => {
      approval.querySelector('span').textContent = actionMode === 'allow' ? 'Allow actions' : 'Ask first';
      depth.querySelector('span').textContent = answerDepth === 'detailed' ? 'Detailed' : 'Concise';
      root.querySelectorAll('[data-action-mode]').forEach(button => button.setAttribute('aria-checked', String(button.dataset.actionMode === actionMode)));
      root.querySelectorAll('[data-answer-depth]').forEach(button => button.setAttribute('aria-checked', String(button.dataset.answerDepth === answerDepth)));
    };
    const toggleMenu = button => {
      const menu = button.parentElement.querySelector('.nika-menu');
      const opening = menu.hidden;
      closeMenus();
      menu.hidden = !opening;
      button.setAttribute('aria-expanded', String(opening));
    };
    approval.addEventListener('click', () => toggleMenu(approval));
    depth.addEventListener('click', () => toggleMenu(depth));
    root.addEventListener('click', event => {
      const actionChoice = event.target.closest('[data-action-mode]');
      const depthChoice = event.target.closest('[data-answer-depth]');
      if (actionChoice) {
        actionMode = actionChoice.dataset.actionMode === 'allow' ? 'allow' : 'ask';
        try { localStorage.setItem(`nika.actionMode:${preferenceKey}`, actionMode); } catch {}
        syncChoices(); closeMenus(); input.focus();
      } else if (depthChoice) {
        answerDepth = depthChoice.dataset.answerDepth === 'detailed' ? 'detailed' : 'concise';
        try { localStorage.setItem(`nika.answerDepth:${preferenceKey}`, answerDepth); } catch {}
        syncChoices(); closeMenus(); input.focus();
      } else if (!event.target.closest('.nika-menu-wrap')) closeMenus();
    });
    syncChoices();
    const performAction = action => {
      status.textContent = clean(action.departure) || `Opening ${clean(action.label) || 'that section'}...`;
      const outcome = navigate(action, pages, accent);
      if (outcome.ok && outcome.samePage && matchMedia('(max-width:520px)').matches) setOpen(false);
      if (!outcome.ok && outcome.samePage) status.textContent = 'I found more than one matching section, so I did not guess. Ask for a more specific heading.';
      return outcome;
    };
    const requestApproval = action => {
      const card = document.createElement('div');
      card.className = 'nika-action-card';
      card.innerHTML = `<span>${escapeHtml(clean(action.departure) || `Open ${clean(action.label) || 'that section'}?`)}</span><button type="button">Continue</button>`;
      card.querySelector('button').addEventListener('click', () => {
        card.querySelector('button').disabled = true;
        performAction(action);
      });
      log.append(card);
      log.scrollTop = log.scrollHeight;
    };
    starters?.addEventListener('click', event => {
      const button = event.target.closest('button[data-question]');
      if (!button) return;
      input.value = button.dataset.question || '';
      form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
    });
    const remember = (role, content, context = pageContext(1)) => {
      history.push({
        role,
        content: clean(content).slice(0, 4000),
        page: {
          path: clean(context.path).slice(0, 500),
          title: clean(context.title).slice(0, 180),
          activeSection: clean(context.activeSection?.label).slice(0, 180)
        }
      });
      history = history.slice(-(Number(settings.historyTurns) || DEFAULTS.historyTurns) * 2);
      try { sessionStorage.setItem(historyKey, JSON.stringify(history)); } catch {}
    };

    form.addEventListener('submit', async event => {
      event.preventDefault();
      const question = clean(input.value);
      if (!question || send.disabled) return;
      input.value = '';
      message('user', question);
      const livePage = pageContext(Number(settings.contextCharacters) || DEFAULTS.contextCharacters);
      remember('user', question, livePage);
      send.disabled = true;
      status.textContent = 'Thinking...';
      try {
        const response = await fetch(`${endpoint}/chat`, {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
          body: JSON.stringify({ message: question, history, page: livePage, answerDepth, actionMode })
        });
        const result = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(clean(result.message || result.error) || `Request failed (${response.status})`);
        const answer = clean(result.message) || 'I could not produce an answer for that.';
        message('assistant', answer);
        remember('assistant', answer, livePage);
        if (result.action && settings.autoNavigate !== false) {
          status.textContent = '';
          if (actionMode === 'ask') requestApproval(result.action);
          else setTimeout(() => performAction(result.action), 450);
        } else status.textContent = '';
      } catch (error) {
        message('assistant error', error.message || 'Nika could not answer. Please try again.');
        status.textContent = '';
      } finally {
        send.disabled = false;
        input.focus();
      }
    });

    const SpeechRecognition = global.SpeechRecognition || global.webkitSpeechRecognition;
    if (settings.dictation === false || !SpeechRecognition) {
      mic.disabled = true;
      mic.title = settings.dictation === false ? 'Dictation is disabled by this site' : 'Dictation is not supported in this browser';
    } else {
      const recognition = new SpeechRecognition();
      recognition.lang = clean(settings.dictationLanguage) || document.documentElement.lang || navigator.language || 'en-US';
      recognition.interimResults = true;
      recognition.continuous = true;
      const limit = Number(input.maxLength) || 4000;
      let listening = false, wanted = false, cancelled = false, dictationError = '', prefix = '', suffix = '', committed = '', sessionFinal = '', interim = '', segments = [];
      let startedAt = 0, timer = 0, stream = null, audioContext = null, analyser = null, frame = 0, wave = [];
      const joinParts = parts => parts.map(clean).filter(Boolean).join(' ');
      // The browser may rewrite interim recognition several times. Only put
      // stable chunks in the editable field; the waveform remains live while
      // the current phrase is still provisional.
      const transcript = () => joinParts([committed, sessionFinal]);
      const updateSegments = event => {
        const start = Number.isInteger(event.resultIndex) ? event.resultIndex : 0;
        for (let i = start; i < event.results.length; i++) {
          const result = event.results[i];
          segments[i] = { text: result?.[0]?.transcript || '', final: Boolean(result?.isFinal) };
        }
        if (event.results.length < segments.length) segments = segments.filter((segment, index) => index < event.results.length || segment?.final);
        sessionFinal = joinParts(segments.filter(segment => segment?.final).map(segment => segment.text));
        interim = joinParts(segments.filter(segment => segment && !segment.final).map(segment => segment.text));
      };
      const joinAtCursor = (left, speech, right) => {
        speech = clean(speech);
        const before = speech && left && /\S$/.test(left) && /^\S/.test(speech) ? ' ' : '';
        const after = speech && right && /\S$/.test(speech) && /^\S/.test(right) ? ' ' : '';
        const room = Math.max(0, limit - left.length - right.length - before.length - after.length);
        return `${left}${before}${speech.slice(0, room)}${after}${right}`.slice(0, limit);
      };
      const renderTranscript = () => {
        input.value = joinAtCursor(prefix, transcript(), suffix);
        const caret = Math.min(input.value.length, prefix.length + transcript().length + 1);
        try { input.setSelectionRange(caret, caret); } catch {}
      };
      const drawWave = () => {
        if (!wanted) return;
        const dpr = Math.min(2, devicePixelRatio || 1), width = Math.max(1, Math.round(dictationCanvas.clientWidth * dpr)), height = Math.max(1, Math.round(dictationCanvas.clientHeight * dpr));
        if (dictationCanvas.width !== width || dictationCanvas.height !== height) { dictationCanvas.width = width; dictationCanvas.height = height; }
        let level = .035;
        if (analyser) { const data = new Uint8Array(analyser.fftSize); analyser.getByteTimeDomainData(data); let sum = 0; for (const sample of data) { const value = (sample - 128) / 128; sum += value * value; } level = Math.min(1, Math.sqrt(sum / data.length) * 4.8); }
        wave.push(level); if (wave.length > 54) wave.shift();
        const context = dictationCanvas.getContext('2d'); context.clearRect(0, 0, width, height); context.fillStyle = '#d7d7d7'; context.globalAlpha = .68;
        const gap = width / 54, center = height / 2, reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
        for (let index = 0; index < 54; index++) { const sample = wave[index] ?? .025; const barHeight = reduced ? Math.max(2 * dpr, Math.min(height * .24, sample * height)) : Math.max(2 * dpr, Math.min(height * .88, sample * height)); const barWidth = sample > .09 ? Math.max(2 * dpr, gap * .42) : Math.max(1.5 * dpr, gap * .22); context.beginPath(); context.roundRect(index * gap + (gap - barWidth) / 2, center - barHeight / 2, barWidth, barHeight, barWidth / 2); context.fill(); }
        frame = requestAnimationFrame(drawWave);
      };
      const stopWave = () => { cancelAnimationFrame(frame); frame = 0; stream?.getTracks().forEach(track => track.stop()); stream = null; analyser = null; if (audioContext) { audioContext.close().catch(() => {}); audioContext = null; } };
      const startWave = async () => { wave = []; drawWave(); try { stream = await navigator.mediaDevices?.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } }); if (!wanted) return stopWave(); audioContext = new (global.AudioContext || global.webkitAudioContext)(); analyser = audioContext.createAnalyser(); analyser.fftSize = 1024; analyser.smoothingTimeConstant = .55; audioContext.createMediaStreamSource(stream).connect(analyser); } catch { analyser = null; } };
      const finish = () => {
        listening = false; wanted = false; clearInterval(timer); timer = 0; stopWave(); form.classList.remove('dictating'); dictation.hidden = true; mic.classList.remove('listening'); mic.setAttribute('aria-label', 'Start dictation');
        if (cancelled) input.value = joinAtCursor(prefix, '', suffix); else { committed = joinParts([committed, sessionFinal, interim]); sessionFinal = ''; interim = ''; segments = []; renderTranscript(); }
        status.textContent = dictationError || (cancelled ? 'Dictation cancelled.' : input.value ? 'Dictation added.' : 'Dictation stopped.'); input.focus();
      };
      const stop = cancel => { if (!wanted && !listening) return; cancelled = Boolean(cancel); wanted = false; try { cancel ? recognition.abort() : recognition.stop(); } catch { finish(); } };
      const begin = () => {
        const start = Number.isInteger(input.selectionStart) ? input.selectionStart : input.value.length, end = Number.isInteger(input.selectionEnd) ? input.selectionEnd : start;
        prefix = input.value.slice(0, start); suffix = input.value.slice(end); committed = ''; sessionFinal = ''; interim = ''; segments = []; cancelled = false; dictationError = ''; wanted = true; startedAt = Date.now();
        form.classList.add('dictating'); dictation.hidden = false; mic.classList.add('listening'); mic.setAttribute('aria-label', 'Stop dictation'); dictationTime.textContent = '0:00'; status.textContent = 'Listening...';
        timer = setInterval(() => { const seconds = Math.floor((Date.now() - startedAt) / 1000); dictationTime.textContent = `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}`; }, 250); startWave();
        try { recognition.start(); } catch { wanted = false; finish(); status.textContent = 'Dictation is already changing state. Try again in a moment.'; }
      };
      recognition.onstart = () => { listening = true; };
      recognition.onresult = event => { updateSegments(event); renderTranscript(); };
      recognition.onerror = event => {
        if (event.error === 'aborted') return;
        if (event.error === 'not-allowed' || event.error === 'service-not-allowed') { wanted = false; dictationError = 'Microphone permission was not granted. Allow microphone access and try again.'; }
        else if (event.error !== 'no-speech') status.textContent = 'Dictation paused; reconnecting...';
      };
      recognition.onend = () => {
        listening = false;
        committed = joinParts([committed, sessionFinal, interim]); sessionFinal = ''; interim = ''; segments = []; renderTranscript();
        if (wanted) setTimeout(() => { if (wanted) try { recognition.start(); } catch { wanted = false; finish(); } }, 180); else finish();
      };
      mic.addEventListener('click', () => wanted ? stop(false) : begin());
      dictationStop.addEventListener('click', () => stop(false));
      dictationCancel.addEventListener('click', () => stop(true));
      close.addEventListener('click', () => { if (wanted) stop(false); });
      addEventListener('pagehide', () => { if (wanted) stop(false); else stopWave(); }, { once: true });
    }

    restorePending();
    return Object.freeze({ open: () => setOpen(true), close: () => setOpen(false) });
  }

  global.Nika = Object.freeze({ mount, navigate, pageContext, allowedDestination });
  if (global.NikaConfig) {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => mount(global.NikaConfig), { once: true });
    else mount(global.NikaConfig);
  }
})(window);
